import React from 'react';
import type { Certification } from '../types';

const certifications: Certification[] = [
  {
    name: 'Offensive Security Certified Professional (OSCP)',
    provider: 'Offensive Security',
    status: 'planned',
  },
  {
    name: 'Professional Machine Learning Engineer',
    provider: 'Google Cloud',
    status: 'planned',
  },
  {
    name: 'Certified Ethical Hacker (CEH)',
    provider: 'EC-Council',
    status: 'planned',
  },
  {
    name: 'Microsoft Azure Security Engineer Associate',
    provider: 'Microsoft',
    status: 'planned',
  },
];

export default function Certifications() {
  return (
    <section className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
          Certifications & Learning Path
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {certifications.map((cert) => (
            <div
              key={cert.name}
              className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow"
            >
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                {cert.name}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                {cert.provider}
              </p>
              <span className="inline-block px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full text-sm">
                {cert.status === 'planned' ? 'Planned' : cert.status === 'in-progress' ? 'In Progress' : 'Completed'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}