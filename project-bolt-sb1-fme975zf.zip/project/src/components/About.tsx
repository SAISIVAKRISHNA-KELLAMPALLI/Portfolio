import React from 'react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
          About Me
        </h2>
        <div className="max-w-3xl mx-auto">
          <div className="prose dark:prose-invert">
            <p className="text-lg text-gray-600 dark:text-gray-300">
              I am an aspiring AI & Cybersecurity professional with a deep passion for technology,
              business, and innovation. My journey in tech has been driven by a curiosity to understand
              and implement cutting-edge solutions that make a difference.
            </p>
            <p className="text-lg text-gray-600 dark:text-gray-300 mt-4">
              Currently focusing on advancing my expertise in Machine Learning and Cybersecurity,
              I believe in the power of technology to transform businesses and enhance digital security.
              My approach combines technical knowledge with practical implementation, always staying
              updated with the latest industry trends and best practices.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}