import React from 'react';
import type { Experience } from '../types';

const experiences: Experience[] = [
  {
    company: 'CSI',
    role: 'Web Development Intern',
    period: 'Jun 2023 - Aug 2023',
    description: 'Developed and maintained web applications using .NET framework. Implemented responsive designs and improved user experience.',
  },
  {
    company: 'Intrain Tech',
    role: 'Machine Learning Intern',
    period: 'Mar 2023 - May 2023',
    description: 'Worked on stock price prediction using machine learning algorithms. Developed and deployed ML models for real-time predictions.',
  },
];

export default function Experience() {
  return (
    <section id="experience" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
          Professional Experience
        </h2>
        <div className="max-w-3xl mx-auto">
          <div className="space-y-8">
            {experiences.map((exp) => (
              <div
                key={exp.company}
                className="bg-white dark:bg-gray-900 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                    {exp.role} at {exp.company}
                  </h3>
                  <span className="text-gray-600 dark:text-gray-400 text-sm">
                    {exp.period}
                  </span>
                </div>
                <p className="text-gray-600 dark:text-gray-300">
                  {exp.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}