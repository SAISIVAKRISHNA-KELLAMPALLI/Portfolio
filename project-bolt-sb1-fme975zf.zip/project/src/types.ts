export type Project = {
  title: string;
  description: string;
  link?: string;
  image: string;
  tags: string[];
};

export type Experience = {
  company: string;
  role: string;
  period: string;
  description: string;
};

export type Certification = {
  name: string;
  provider: string;
  status: 'planned' | 'in-progress' | 'completed';
};